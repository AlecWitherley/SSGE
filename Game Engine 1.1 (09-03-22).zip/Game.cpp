#include "Game.h"
#include "Definitions.h"

Game::Game() : window(WIN_NAME) {
    deltaTime = clock.restart().asSeconds();
}

void Game::Update() {
    window.Update();
    //Define Variables Here
    //using DIR - texture.loadFromFile(DIR.Get() + "texture.png");

}

void Game::LateUpdate() {}

void Game::Draw() {
    window.BeginDraw();
    //window.Draw(); - Draw
    window.EndDraw();
}

void Game::CalculateDeltaTime() {
    deltaTime = clock.restart().asSeconds();
}
void Game::CaptureInput(){
    input.Update();
}
bool Game::IsRunning() const {
    return window.IsOpen();
}