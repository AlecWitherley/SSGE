#pragma once

#include <SFML/Graphics.hpp>

#include "Win.h"
#include "Definitions.h"
#include "Dir.h"
#include "Input.h"

class Game{
public:
    Game();

    void Update();
    void LateUpdate();
    void Draw();
    void CalculateDeltaTime();
    bool IsRunning() const;
    void CaptureInput();

private:
    Win window;
    WorkingDirectory DIR;
    Input input;
    sf::Clock clock;
    float deltaTime;

    //Declare Variables Here 
};