#include "Input.h"
#include "Win.h"
#include "Definitions.h"

void Input::Update() {
	lastFrameKeys.SetMask(thisFrameKeys);

	LEFT_PRESSED(sf::Keyboard::isKeyPressed(sf::Keyboard::Left));
	RIGHT_PRESSED(sf::Keyboard::isKeyPressed(sf::Keyboard::Right));
	UP_PRESSED(sf::Keyboard::isKeyPressed(sf::Keyboard::Up));
	DOWN_PRESSED(sf::Keyboard::isKeyPressed(sf::Keyboard::Down));

	ESC_PRESSED sf::Keyboard::isKeyPressed(sf::Keyboard::Escape);
}
bool Input::IsKeyPressed(Key keycode){
	return thisFrameKeys.GetBit((int)keycode);
}

bool Input::IsKeyDown(Key keycode){
	bool lastFrame = lastFrameKeys.GetBit((int)keycode);
	bool thisFrame = thisFrameKeys.GetBit((int)keycode);
	return thisFrame && !lastFrame;
}

bool Input::IsKeyUp(Key keycode){
	bool lastFrame = lastFrameKeys.GetBit((int)keycode);
	bool thisFrame = thisFrameKeys.GetBit((int)keycode);
	return !thisFrame && lastFrame;
}