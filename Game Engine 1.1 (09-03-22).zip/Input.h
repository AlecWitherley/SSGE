#pragma once
#include "Bitmask.h"

class Input{
public:
	enum class Key{
		None = 0,

		Left = 1,
		Right = 2,
		Up = 3,
		Down = 4,

		W = 5,
		S = 6,
		A = 7, 
		D = 8,

		Esc = 9,

		Shift = 10,
		Enter = 11,
		Space = 12
	};
	void Update();

private:
	bool IsKeyPressed(Key keycode);
	bool IsKeyDown(Key keycode);
	bool IsKeyUp(Key keycode);

	Bitmask thisFrameKeys;
	Bitmask lastFrameKeys;
};

