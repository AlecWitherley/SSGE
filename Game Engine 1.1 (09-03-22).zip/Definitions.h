#pragma once

//WINDOWS
#define WIN_WIDTH 500
#define WIN_HEIGHT 500
#define WIN_NAME "Game Engine"
#define WIN_STYLE Style::Default
#define WIN_COLOUR Black
#define WIN_AA_LEVEL 16
#define WIN_FPS_CAP 60
#define WIN_V_SYNC true

//KINAMATIC BODY
#define KIN_SPR "texture1.png"
#define KIN_HEIGHT 100
#define KIN_WIDTH 50
#define KIN_SPEED 50.0
#define KIN_JUMP 100.0

//KEY PRESSED
#define LEFT_PRESSED thisFrameKeys.SetBit((int)Key::Left),
#define RIGHT_PRESSED thisFrameKeys.SetBit((int)Key::Right),
#define UP_PRESSED thisFrameKeys.SetBit((int)Key::Up),
#define DOWN_PRESSED thisFrameKeys.SetBit((int)Key::Down),

#define W_PRESSED thisFrameKeys.SetBit((int)Key::W),
#define S_PRESSED thisFrameKeys.SetBit((int)Key::S),
#define A_PRESSED thisFrameKeys.SetBit((int)Key::A),
#define D_PRESSED thisFrameKeys.SetBit((int)Key::D),

#define SPACE_PRESSED thisFrameKeys.SetBit((int)Key::Space),
#define ENTER_PRESSED thisFrameKeys.SetBit((int)Key::Enter),
#define SHIFT_PRESSED thisFrameKeys.SetBit((int)Key::Shift),

#define ESC_PRESSED thisFrameKeys.SetBit((int)Key::Esc), 

#define elif else if