#include "Win.h"
#include "Definitions.h"
#include "Animations.h"

sf::Clock delta;

sf::Sprite SRun;
sf::Texture TRun;

sf::Sprite SIdle;
sf::Texture TIdle;

sf::Sprite SFlip;
sf::Texture TFlip;

int x = 0;

int main(){
    Win window(WIN_NAME);

    TRun.loadFromFile(RUN_PATH);
    SRun.setTexture(TRun);

    TIdle.loadFromFile(IDLE_PATH);
    SIdle.setTexture(TIdle);

    TFlip.loadFromFile(RUN_FLIP_PATH);
    SFlip.setTexture(TFlip);

    SRun.setPosition(sf::Vector2f(200,200));
    SIdle.setPosition(sf::Vector2f(200, 200));
    SFlip.setPosition(sf::Vector2f(200, 200));

    Animation Run(SRun);
    Animation Idle(SIdle);
    Animation Run_Flip(SFlip);

    while (window.IsOpen()) {
        sf::Time dt = delta.restart();
        
        window.Update(dt.asSeconds());
        
        for (int i = 0; i < IDLE_TOTAL; i++) {
            Idle.addFrame({ sf::IntRect(x,0,IDLE_WIDTH,IDLE_HEIGHT), IDLE_DELAY });
            if (x <= IDLE_MAX - IDLE_END_EXTRA) {
                x = x + IDLE_ADD;
            }
            else {
                x = 0;
            }
        }
        for (int i = 0; i < RUN_TOTAL; i++) {
            Run.addFrame({ sf::IntRect(x,0,RUN_WIDTH,RUN_HEIGHT), RUN_DELAY });
            if (x <= RUN_MAX - RUN_END_EXTRA) {
                x = x + RUN_ADD;
            }
            else {
                x = 0;
            }
        }
        for (int i = 0; i < RUN_FLIP_TOTAL; i++) {
            Run_Flip.addFrame({ sf::IntRect(x,0,RUN_FLIP_WIDTH,RUN_FLIP_HEIGHT), RUN_FLIP_DELAY });
            if (x <= RUN_FLIP_MAX - RUN_FLIP_END_EXTRA) {
                x = x + RUN_FLIP_ADD;
            }
            else {
                x = 0;
            }
        }
        window.BeginDraw();
        if (RIGHT_PRESSED) {
            window.Draw(SRun);
            Run.update(dt.asSeconds());
        }
        elif(LEFT_PRESSED) {
            window.Draw(SFlip);
            Run_Flip.update(dt.asSeconds());
        }
        else {
            window.Draw(SIdle);
            Idle.update(dt.asSeconds());
        }

        window.EndDraw();
    }
    return 0;
}