#pragma once
#include <SFML/Graphics.hpp>

struct Frame {
    sf::IntRect rect;
    double duration;
};

class Animation {
    std::vector<Frame> frames;
    double totalLength;
    double totalProgress;
    sf::Sprite* target;
public:
    Animation(sf::Sprite& target) {
        this->target = &target;
        totalProgress = 0.0;
    }
    
    void addFrame(Frame&& frame) {
        frames.push_back(std::move(frame));
        totalLength += frame.duration;
    }
    void update(double elapsed) {
        totalProgress += elapsed;
        double progress = totalProgress;
        for (auto frame : frames) {
            progress -= (frame).duration;

            if (progress <= 0.0 || &(frame) == &frames.back())
            {
                target->setTextureRect((frame).rect);
                break;
            }
        }
    }
};
/*
* ------FUNCTIONAL USE--------

#include <SFML/Graphics.hpp>
#include "Definitions.h"
#include "Animations.h"

int main(){
    sf::RenderWindow window(sf::VideoMode(200, 200), "Animations");
    sf::Clock delta;
    int x = 0;
    //Sprites
    sf::Sprite Left_Run;
    sf::Texture Left_Run_text;
    //Assign
    Left_Run_text.loadFromFile("a.png");
    Left_Run.setTexture(Left_Run_text);
    //Animation
    Animation LRun(Left_Run);

    while (window.isOpen()){
        sf::Event event;
        sf::Time dt = delta.restart();

        while (window.pollEvent(event)){
            if (event.type == sf::Event::Closed)
                window.close();
        }
        for (int i = 0; i < TOTAL; i++) {
            LRun.addFrame({ sf::IntRect(x,0,WIDTH,HEIGHT), DELAY });
            if (x <= MAX-END_EXTRA) {
                x = x + ADD;
            }
            else {
                x = 0;
            }
        }

        //mySprite.move(velocity * dt.AsSeconds());
        window.clear();
        window.draw(Left_Run);
        LRun.update(dt.asSeconds());
        window.display();
    }

    return 0;
}
*/