#ifndef Window_hpp
#define Window_hpp

#include <SFML/Graphics.hpp>

class Win{
public:
    Win(const std::string& windowName);

    void Update();
    void BeginDraw();
    void Draw(const sf::Drawable& drawable);
    void EndDraw();
    bool IsOpen() const;

private:
    sf::RenderWindow window;
};

#endif
