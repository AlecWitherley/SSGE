#include "Game.h"
#include "Definitions.h"

Game::Game() : window(WIN_NAME){
    deltaTime = clock.restart().asSeconds();
}

void Game::Update(){
    window.Update();
    //What the variables do
}

void Game::LateUpdate(){}

void Game::Draw(){
    window.BeginDraw();
    //window.Draw(); - Draw Something
    window.EndDraw();
}

void Game::CalculateDeltaTime(){
    deltaTime = clock.restart().asSeconds();
}

void Game::Input() { // Allows the use of "elif" instead of "else if"
    if (UP_PRESSED) {}
    if (LEFT_PRESSED){}
    if (RIGHT_PRESSED){}
    if (DOWN_PRESSED) {}

    if (W_PRESSED){}
    if (S_PRESSED){}
    if (A_PRESSED){}
    if (D_PRESSED){}

    if (SPACE_PRESSED){}
    if (ENTER_PRESSED){}
    if (SHIFT_PRESSED){}
}

bool Game::IsRunning() const{
    return window.IsOpen();
}