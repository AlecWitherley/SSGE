/*
#include "Game.h"
#include "Definitions.h"

Game::Game() : window(WIN_NAME) {
    deltaTime = clock.restart().asSeconds();
}

void Game::Update() {
    window.Update();

    Kin_Text.loadFromFile(KIN_SPR);
    const sf::Vector2f& spritePos = Kin_Spr.getPosition();
    Kin_Spr.setTexture(Kin_Text);

    coll.setSize(sf::Vector2f(KIN_WIDTH, KIN_HEIGHT));
    coll.setPosition(Kin_Spr.getPosition());

    floor.setSize(sf::Vector2f(500, 50));
    floor.setFillColor(sf::Color::Blue);
    floor.setPosition(sf::Vector2f(0, 450));

    const int moveSpeed = 100;
    int xMove = 0;
    int yMove = 0;

    float xFrameMove = xMove * deltaTime;
    float yFrameMove = yMove * deltaTime;

    Kin_Spr.move(velocity * deltaTime);
}

void Game::LateUpdate() {}

void Game::Draw() {
    window.BeginDraw();
    window.Draw(floor);
    //window.Draw(coll); - Collition shape
    window.Draw(Kin_Spr);
    window.EndDraw();
}

void Game::CalculateDeltaTime() {
    deltaTime = clock.restart().asSeconds();
}

void Game::Input() {
    if (UP_PRESSED && canJump == true) {
        canJump = false;
        velocity.y = -sqrt(2.0 * 981.0f * KIN_JUMP);
    }
    else {
        if (coll.getGlobalBounds().intersects(floor.getGlobalBounds())) {
            canJump = true;
            velocity.y = 0;
        }
        else {
            velocity.y += 981.0f * deltaTime;
        }
    }
    if (LEFT_PRESSED) {
        velocity.x -= KIN_SPEED;
    }
    elif(RIGHT_PRESSED) {
        velocity.x += KIN_SPEED;
    }
    else {
        if (velocity.x > 0) {
            velocity.x -= 50;
        }
        elif(velocity.x < 0) {
            velocity.x += 50;
        }
        else {
            velocity.x = 0;
        }
    }
    if (DOWN_PRESSED) {}

    if (W_PRESSED) {}
    if (S_PRESSED) {}
    if (A_PRESSED) {}
    if (D_PRESSED) {}

    if (SPACE_PRESSED) {}
    if (ENTER_PRESSED) {}
    if (SHIFT_PRESSED) {}
}

bool Game::IsRunning() const {
    return window.IsOpen();
}
*/