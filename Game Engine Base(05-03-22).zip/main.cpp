#include "Win.h"
#include "Definitions.h"
#include "Game.h"

int main(){
    Game game;

    while (game.IsRunning()){
        game.Input();
        game.Update();
        game.LateUpdate();
        game.Draw();
        game.CalculateDeltaTime();
    }

    return 0;
}