#pragma once
#ifndef Game_hpp
#define Game_hpp

#include <SFML/Graphics.hpp>

#include "Win.h"
#include "Definitions.h"

class Game{
public:
    Game();

    void Update();
    void LateUpdate();
    void Draw();
    void CalculateDeltaTime();
    void Input();
    bool IsRunning() const;

private:
    Win window;
    //Add variables 
    sf::Clock clock;
    float deltaTime;
};

#endif